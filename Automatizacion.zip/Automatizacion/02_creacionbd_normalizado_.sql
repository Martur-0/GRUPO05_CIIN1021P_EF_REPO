/* ============================================================================
   PROYECTO INTEGRADOR - DIRESA LA LIBERTAD
   Dataset fuente: MINSA - Vigilancia Epidemiológica de Dengue 2000-2024
   (datosabiertos.gob.pe)

   SCRIPT: 02_schema_normalizado_3NF.sql
   Objetivo: crear la base de datos, la tabla de staging (destino del ETL de
   ingesta) y el modelo normalizado hasta 3FN resultante del análisis de
   dependencias funcionales documentado en el informe de normalización.

   Motor: Microsoft SQL Server 2019+
============================================================================ */

IF DB_ID('DIRESA_LaLibertad_Dengue') IS NULL
BEGIN
    CREATE DATABASE DIRESA_LaLibertad_Dengue;
END
GO

USE DIRESA_LaLibertad_Dengue;
GO

/* ----------------------------------------------------------------------
   1. TABLA DE STAGING (área de aterrizaje)
   Recibe la carga cruda proveniente del archivo del MINSA (o del CSV ya
   pre-limpiado por el ETL Python de la Fase 1) ANTES de validar tipos y
   reglas de negocio. Tipos permisivos (VARCHAR) a propósito: el objetivo
   del staging es aceptar el dato tal como llega y dejar que los
   procedimientos almacenados del Paso 2 hagan el casteo y la validación
   dentro de un TRY/CATCH controlado, en vez de que un CSV mal formado
   rompa la carga completa por un error de tipo a nivel de BULK INSERT.
---------------------------------------------------------------------- */
IF OBJECT_ID('dbo.Staging_CasoVigilancia', 'U') IS NOT NULL
    DROP TABLE dbo.Staging_CasoVigilancia;
GO
CREATE TABLE dbo.Staging_CasoVigilancia (
    id_staging       INT IDENTITY(1,1) PRIMARY KEY,
    id_origen        VARCHAR(20)   NULL,   -- trazabilidad a la fila del CSV fuente
    departamento     VARCHAR(60)   NULL,
    provincia        VARCHAR(60)   NULL,
    distrito         VARCHAR(60)   NULL,
    localidad        VARCHAR(150)  NULL,
    enfermedad       VARCHAR(100)  NULL,
    ano              VARCHAR(10)   NULL,
    semana           VARCHAR(10)   NULL,
    diagnostic       VARCHAR(10)   NULL,
    diresa           VARCHAR(10)   NULL,
    ubigeo           VARCHAR(10)   NULL,
    localcod         VARCHAR(30)   NULL,
    edad             VARCHAR(20)   NULL,
    tipo_edad        VARCHAR(5)    NULL,
    sexo             VARCHAR(5)    NULL,
    fecha_staging    DATETIME2     NOT NULL DEFAULT SYSDATETIME(),
    estado_validacion VARCHAR(15) NOT NULL DEFAULT 'PENDIENTE', -- PENDIENTE|VALIDO|RECHAZADO
    procesado        BIT           NOT NULL DEFAULT 0
);
GO

/* ----------------------------------------------------------------------
   2. MODELO NORMALIZADO (3FN)
   Ver informe "Normalización 1FN-2FN-3FN" para la justificación completa
   de cada dependencia funcional identificada. Resumen de las decisiones:

   - ubigeo -> departamento, provincia, distrito, diresa   (dependencia
     transitiva detectada en la tabla plana original: id_caso -> ubigeo ->
     departamento). Se extrae Ubicacion.
   - ubigeo -> {localidad_1..N}  (relación 1:N; cada ubigeo agrupa en
     promedio 21 localidades distintas, hasta 646 en el caso máximo).
     Se extrae Localidad como tabla hija de Ubicacion.
   - diagnostic <-> enfermedad (dependencia funcional 1:1 confirmada sobre
     los 3 códigos CIE-10 presentes: A97.0, A97.1, A97.2). Se extrae
     Enfermedad.
   - El resto de atributos (ano, semana, edad, tipo_edad, sexo) dependen
     única y directamente de la clave primaria del caso (id_caso), por lo
     que permanecen en la tabla de hechos CasoVigilancia.
---------------------------------------------------------------------- */

IF OBJECT_ID('dbo.CasoVigilancia', 'U') IS NOT NULL DROP TABLE dbo.CasoVigilancia;
IF OBJECT_ID('dbo.Localidad', 'U') IS NOT NULL DROP TABLE dbo.Localidad;
IF OBJECT_ID('dbo.Enfermedad', 'U') IS NOT NULL DROP TABLE dbo.Enfermedad;
IF OBJECT_ID('dbo.Ubicacion', 'U') IS NOT NULL DROP TABLE dbo.Ubicacion;
GO

-- 2.1 Ubicacion: clave natural ubigeo (INEI), determina de forma única
--     departamento/provincia/distrito/diresa tras la corrección de
--     inconsistencias aplicada en el ETL (regla de moda por ubigeo).
CREATE TABLE dbo.Ubicacion (
    ubigeo        CHAR(6)      NOT NULL PRIMARY KEY,
    departamento  VARCHAR(60)  NOT NULL,
    provincia     VARCHAR(60)  NOT NULL,
    distrito      VARCHAR(60)  NOT NULL,
    diresa        VARCHAR(10)  NULL
);
GO

-- 2.2 Localidad: relación 1:N respecto de Ubicacion. Se conserva el
--     formato original de localcod (numérico vs. alfanumérico) más un
--     atributo derivado 'tipo_localcod' para trazabilidad de calidad.
CREATE TABLE dbo.Localidad (
    id_localidad      INT IDENTITY(1,1) PRIMARY KEY,
    ubigeo            CHAR(6)      NOT NULL,
    localidad_nombre  VARCHAR(150) NOT NULL,
    localcod          VARCHAR(30)  NULL,
    tipo_localcod     VARCHAR(20)  NOT NULL DEFAULT 'NO_ESPECIFICADO'
        CONSTRAINT CK_Localidad_Tipo CHECK (tipo_localcod IN ('NUMERICO','ALFANUMERICO','NO_ESPECIFICADO')),
    CONSTRAINT FK_Localidad_Ubicacion FOREIGN KEY (ubigeo) REFERENCES dbo.Ubicacion(ubigeo),
    CONSTRAINT UQ_Localidad UNIQUE (ubigeo, localidad_nombre, localcod)
);
GO

-- 2.3 Enfermedad: catálogo cerrado CIE-10 (3 valores en el dataset actual,
--     diseñado para escalar a otras enfermedades de notificación obligatoria).
CREATE TABLE dbo.Enfermedad (
    diagnostic         VARCHAR(10) NOT NULL PRIMARY KEY,   -- código CIE-10
    enfermedad_nombre  VARCHAR(100) NOT NULL
);
GO

-- 2.4 CasoVigilancia: tabla de hechos en 3FN. Todo atributo no clave
--     depende única, directa y no transitivamente de id_caso.
CREATE TABLE dbo.CasoVigilancia (
    id_caso                 BIGINT IDENTITY(1,1) PRIMARY KEY,
    id_origen               VARCHAR(20)  NULL,        -- trazabilidad a la fila fuente/staging
    ubigeo                  CHAR(6)      NOT NULL,
    id_localidad             INT          NULL,
    diagnostic              VARCHAR(10)  NOT NULL,
    ano                     SMALLINT     NOT NULL,
    semana                  TINYINT      NOT NULL,
    edad                    SMALLINT     NULL,          -- NULL si fue anulada por outlier (ver Log_ExcepcionesETL)
    tipo_edad               CHAR(1)      NOT NULL,
    sexo                    CHAR(1)      NOT NULL,
    flag_posible_duplicado  BIT          NOT NULL DEFAULT 0,
    fecha_carga             DATETIME2    NOT NULL DEFAULT SYSDATETIME(),
    usuario_carga           VARCHAR(100) NOT NULL DEFAULT SUSER_SNAME(),
    CONSTRAINT FK_Caso_Ubicacion  FOREIGN KEY (ubigeo)     REFERENCES dbo.Ubicacion(ubigeo),
    CONSTRAINT FK_Caso_Localidad  FOREIGN KEY (id_localidad) REFERENCES dbo.Localidad(id_localidad),
    CONSTRAINT FK_Caso_Enfermedad FOREIGN KEY (diagnostic)  REFERENCES dbo.Enfermedad(diagnostic),
    CONSTRAINT CK_Caso_Sexo      CHECK (sexo IN ('M','F')),
    CONSTRAINT CK_Caso_TipoEdad  CHECK (tipo_edad IN ('A','M','D')),
    CONSTRAINT CK_Caso_Semana    CHECK (semana BETWEEN 1 AND 53),
    CONSTRAINT CK_Caso_Ano       CHECK (ano BETWEEN 2000 AND 2035),
    CONSTRAINT CK_Caso_Edad      CHECK (edad IS NULL OR edad >= 0)
);
GO

CREATE NONCLUSTERED INDEX IX_CasoVigilancia_Ubigeo_Periodo
    ON dbo.CasoVigilancia (ubigeo, ano, semana) INCLUDE (diagnostic, sexo, edad);
GO

/* ----------------------------------------------------------------------
   3. TABLAS DE AUDITORÍA Y EXCEPCIONES (soporte de Paso 2 y Paso 3)
---------------------------------------------------------------------- */
IF OBJECT_ID('dbo.Log_Auditoria', 'U') IS NOT NULL DROP TABLE dbo.Log_Auditoria;
GO
CREATE TABLE dbo.Log_Auditoria (
    id_log          BIGINT IDENTITY(1,1) PRIMARY KEY,
    tabla_afectada  VARCHAR(50)   NOT NULL,
    operacion       VARCHAR(10)   NOT NULL,   -- INSERT | UPDATE | DELETE
    id_registro     VARCHAR(50)   NULL,
    usuario_bd      VARCHAR(100)  NOT NULL DEFAULT SUSER_SNAME(),
    fecha_hora      DATETIME2     NOT NULL DEFAULT SYSDATETIME(),
    valor_anterior  NVARCHAR(MAX) NULL,
    valor_nuevo     NVARCHAR(MAX) NULL
);
GO

IF OBJECT_ID('dbo.Log_ExcepcionesETL', 'U') IS NOT NULL DROP TABLE dbo.Log_ExcepcionesETL;
GO
CREATE TABLE dbo.Log_ExcepcionesETL (
    id_excepcion   BIGINT IDENTITY(1,1) PRIMARY KEY,
    id_staging     INT           NULL,
    regla          VARCHAR(50)   NOT NULL,
    descripcion    NVARCHAR(500) NOT NULL,
    severidad      VARCHAR(10)   NOT NULL DEFAULT 'INFO',  -- INFO | ADVERTENCIA | ERROR
    fecha_hora     DATETIME2     NOT NULL DEFAULT SYSDATETIME()
);
GO

/* ----------------------------------------------------------------------
   4. CARGA INICIAL DE CATÁLOGO Enfermedad (dominio cerrado, 3 valores
      confirmados en el relevamiento de la Fase 1)
---------------------------------------------------------------------- */
INSERT INTO dbo.Enfermedad (diagnostic, enfermedad_nombre) VALUES
    ('A97.0', 'DENGUE SIN SIGNOS DE ALARMA'),
    ('A97.1', 'DENGUE CON SIGNOS DE ALARMA'),
    ('A97.2', 'DENGUE GRAVE');
GO
