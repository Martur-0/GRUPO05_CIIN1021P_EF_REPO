/* ============================================================================
   PROYECTO INTEGRADOR - DIRESA LA LIBERTAD
   PASO 2: Objetos de automatización en SQL Server

   Contiene:
     - fn_ClasificarGrupoEtario        (función escalar reutilizable)
     - sp_ValidarStaging               (procedimiento almacenado 1: ingesta+validación)
     - sp_CargarCasoVigilancia         (procedimiento almacenado 2: carga al modelo 3FN)
     - trg_CasoVigilancia_Auditoria    (trigger DML de auditoría)
     - trg_CasoVigilancia_Integridad   (trigger de integridad edad/tipo_edad)

   Requiere haber ejecutado antes: 02_schema_normalizado_3NF.sql
============================================================================ */

USE DIRESA_LaLibertad_Dengue;
GO

/* ============================================================================
   FUNCIÓN 1 (escalar): fn_ClasificarGrupoEtario
   Propósito: normalizar edad + tipo_edad ('A'=años,'M'=meses,'D'=días) a un
   grupo etario estándar en años, reutilizable tanto por los procedimientos
   de carga como por el futuro dashboard de KPIs (Paso 3 / Bloque 3 - BI).
   Parámetros:
     @edad      SMALLINT  - valor numérico de edad (puede ser NULL)
     @tipo_edad CHAR(1)   - 'A' años, 'M' meses, 'D' días
   Comportamiento ante excepciones: si @edad es NULL o el tipo es
   desconocido, retorna 'NO_CLASIFICADO' en vez de fallar (una función no
   puede lanzar TRY/CATCH hacia el llamador de forma bloqueante, por lo que
   se opta por un valor centinela documentado).
============================================================================ */
IF OBJECT_ID('dbo.fn_ClasificarGrupoEtario', 'FN') IS NOT NULL
    DROP FUNCTION dbo.fn_ClasificarGrupoEtario;
GO
CREATE FUNCTION dbo.fn_ClasificarGrupoEtario
(
    @edad      SMALLINT,
    @tipo_edad CHAR(1)
)
RETURNS VARCHAR(20)
AS
BEGIN
    DECLARE @edad_anios DECIMAL(10,2);
    DECLARE @grupo VARCHAR(20);

    IF @edad IS NULL OR @tipo_edad IS NULL
        RETURN 'NO_CLASIFICADO';

    SET @edad_anios =
        CASE @tipo_edad
            WHEN 'A' THEN CAST(@edad AS DECIMAL(10,2))
            WHEN 'M' THEN CAST(@edad AS DECIMAL(10,2)) / 12.0
            WHEN 'D' THEN CAST(@edad AS DECIMAL(10,2)) / 365.0
            ELSE NULL
        END;

    IF @edad_anios IS NULL
        SET @grupo = 'NO_CLASIFICADO';
    ELSE IF @edad_anios < 1
        SET @grupo = 'LACTANTE';
    ELSE IF @edad_anios < 12
        SET @grupo = 'NINO';
    ELSE IF @edad_anios < 18
        SET @grupo = 'ADOLESCENTE';
    ELSE IF @edad_anios < 60
        SET @grupo = 'ADULTO';
    ELSE
        SET @grupo = 'ADULTO_MAYOR';

    RETURN @grupo;
END;
GO

/* ============================================================================
   TRIGGER 1 (integridad): trg_CasoVigilancia_Integridad
   Tipo: INSTEAD OF INSERT
   Propósito: reforzar a nivel de motor una regla de negocio que un simple
   CHECK no puede expresar (depende de la combinación de dos columnas:
   edad y tipo_edad). Rechaza el INSERT completo si algún registro trae una
   combinación imposible (ej. tipo_edad='A' con edad > 120), evitando que
   vuelva a colarse el mismo tipo de error de digitación detectado y
   corregido en el ETL de la Fase 1 (12 casos, ver log_excepciones_etl.csv).
============================================================================ */
IF OBJECT_ID('dbo.trg_CasoVigilancia_Integridad', 'TR') IS NOT NULL
    DROP TRIGGER dbo.trg_CasoVigilancia_Integridad;
GO
CREATE TRIGGER dbo.trg_CasoVigilancia_Integridad
ON dbo.CasoVigilancia
INSTEAD OF INSERT
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        IF EXISTS (
            SELECT 1 FROM inserted
            WHERE (tipo_edad = 'A' AND edad > 120)
               OR (tipo_edad = 'M' AND edad > 1200)   -- > 100 años en meses
               OR (tipo_edad = 'D' AND edad > 43800)  -- > 120 años en días
        )
        BEGIN
            INSERT INTO dbo.Log_ExcepcionesETL (regla, descripcion, severidad)
            SELECT 'EDAD_FUERA_DE_RANGO',
                   CONCAT('Insert rechazado: edad=', edad, ' tipo_edad=', tipo_edad,
                          ' ubigeo=', ubigeo),
                   'ERROR'
            FROM inserted
            WHERE (tipo_edad = 'A' AND edad > 120)
               OR (tipo_edad = 'M' AND edad > 1200)
               OR (tipo_edad = 'D' AND edad > 43800);

            THROW 51000, 'Registro rechazado: combinación edad/tipo_edad fuera de rango fisiológico.', 1;
        END

        INSERT INTO dbo.CasoVigilancia
            (id_origen, ubigeo, id_localidad, diagnostic, ano, semana, edad, tipo_edad, sexo, flag_posible_duplicado)
        SELECT id_origen, ubigeo, id_localidad, diagnostic, ano, semana, edad, tipo_edad, sexo, flag_posible_duplicado
        FROM inserted;
    END TRY
    BEGIN CATCH
        THROW;
    END CATCH
END;
GO

/* ============================================================================
   TRIGGER 2 (auditoría DML): trg_CasoVigilancia_Auditoria
   Tipo: AFTER INSERT, UPDATE, DELETE
   Propósito: cumplir el Art. 11 de la Ley N.° 29733 (medidas de seguridad
   técnica) dejando trazabilidad de quién modificó qué dato y cuándo, algo
   que el diagnóstico inicial de la DIRESA La Libertad señala como
   inexistente hoy. Nota: como el INSERT ahora pasa por el trigger INSTEAD
   OF de integridad, este trigger AFTER se dispara sobre el INSERT real que
   ese trigger ejecuta internamente contra la tabla base.
============================================================================ */
IF OBJECT_ID('dbo.trg_CasoVigilancia_Auditoria', 'TR') IS NOT NULL
    DROP TRIGGER dbo.trg_CasoVigilancia_Auditoria;
GO
CREATE TRIGGER dbo.trg_CasoVigilancia_Auditoria
ON dbo.CasoVigilancia
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    -- NOTA: "FOR JSON AUTO/PATH" exige su propia clausula FROM dentro de la
    -- subconsulta; no basta con arrastrar el alias de la consulta externa
    -- (i.*/d.* solos). Por eso cada subconsulta vuelve a referenciar
    -- inserted/deleted (tablas virtuales disponibles en todo el trigger) y
    -- se correlaciona por id_caso para traer exactamente la fila del JOIN.
    IF EXISTS (SELECT 1 FROM inserted) AND EXISTS (SELECT 1 FROM deleted)
    BEGIN
        INSERT INTO dbo.Log_Auditoria (tabla_afectada, operacion, id_registro, valor_anterior, valor_nuevo)
        SELECT 'CasoVigilancia', 'UPDATE', CAST(i.id_caso AS VARCHAR(50)),
               (SELECT dd.* FROM deleted  dd WHERE dd.id_caso = i.id_caso FOR JSON AUTO),
               (SELECT ii.* FROM inserted ii WHERE ii.id_caso = i.id_caso FOR JSON AUTO)
        FROM inserted i
        JOIN deleted d ON d.id_caso = i.id_caso;
    END
    ELSE IF EXISTS (SELECT 1 FROM inserted)
    BEGIN
        INSERT INTO dbo.Log_Auditoria (tabla_afectada, operacion, id_registro, valor_nuevo)
        SELECT 'CasoVigilancia', 'INSERT', CAST(i.id_caso AS VARCHAR(50)),
               (SELECT ii.* FROM inserted ii WHERE ii.id_caso = i.id_caso FOR JSON AUTO)
        FROM inserted i;
    END
    ELSE IF EXISTS (SELECT 1 FROM deleted)
    BEGIN
        INSERT INTO dbo.Log_Auditoria (tabla_afectada, operacion, id_registro, valor_anterior)
        SELECT 'CasoVigilancia', 'DELETE', CAST(d.id_caso AS VARCHAR(50)),
               (SELECT dd.* FROM deleted dd WHERE dd.id_caso = d.id_caso FOR JSON AUTO)
        FROM deleted d;
    END
END;
GO

/* ============================================================================
   PROCEDIMIENTO ALMACENADO 1: sp_ValidarStaging
   Propósito: validar cada fila cargada en Staging_CasoVigilancia (dominios,
   tipos de dato, existencia de FK) SIN tocar aún el modelo 3FN. Usa
   TRY/CATCH + una transacción con SAVEPOINT por lote para poder revertir
   solo el lote fallido sin perder los lotes previos ya confirmados.
   Alternativa descartada: validar fila por fila con auto-commit implícito.
   Se descartó porque (a) multiplica los round-trips transaccionales del
   motor por cada una de las ~876k filas, y (b) no permite un ROLLBACK
   parcial coherente si el proceso se corta a la mitad de un lote.
============================================================================ */
IF OBJECT_ID('dbo.sp_ValidarStaging', 'P') IS NOT NULL
    DROP PROCEDURE dbo.sp_ValidarStaging;
GO
CREATE PROCEDURE dbo.sp_ValidarStaging
    @tamano_lote INT = 5000
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @filas_validadas INT = 0;
    DECLARE @filas_rechazadas INT = 0;

    BEGIN TRY
        BEGIN TRANSACTION TrxValidacion;
        SAVE TRANSACTION SavepointInicio;

        -- Rechazo: dominios cerrados invalidos
        UPDATE s
        SET estado_validacion = 'RECHAZADO'
        FROM dbo.Staging_CasoVigilancia s
        WHERE s.estado_validacion = 'PENDIENTE'
          AND (
                s.sexo NOT IN ('M','F')
             OR s.tipo_edad NOT IN ('A','M','D')
             OR s.diagnostic NOT IN (SELECT diagnostic FROM dbo.Enfermedad)
             OR TRY_CAST(s.ano AS SMALLINT) IS NULL
             OR TRY_CAST(s.semana AS TINYINT) IS NULL
             OR TRY_CAST(s.semana AS TINYINT) NOT BETWEEN 1 AND 53
             OR LEN(ISNULL(s.ubigeo,'')) <> 6
          );

        SELECT @filas_rechazadas = @@ROWCOUNT;

        INSERT INTO dbo.Log_ExcepcionesETL (id_staging, regla, descripcion, severidad)
        SELECT id_staging, 'VALIDACION_DOMINIO',
               'Fila rechazada en staging por dominio/tipo invalido (sexo, tipo_edad, diagnostic, ano, semana o ubigeo).',
               'ERROR'
        FROM dbo.Staging_CasoVigilancia
        WHERE estado_validacion = 'RECHAZADO' AND id_staging NOT IN (
              SELECT id_staging FROM dbo.Log_ExcepcionesETL WHERE regla = 'VALIDACION_DOMINIO'
        );

        -- Todo lo que no fue rechazado, queda validado
        UPDATE dbo.Staging_CasoVigilancia
        SET estado_validacion = 'VALIDO'
        WHERE estado_validacion = 'PENDIENTE';

        SELECT @filas_validadas = @@ROWCOUNT;

        COMMIT TRANSACTION TrxValidacion;

        SELECT @filas_validadas AS filas_validadas, @filas_rechazadas AS filas_rechazadas;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
            ROLLBACK TRANSACTION TrxValidacion;

        INSERT INTO dbo.Log_ExcepcionesETL (regla, descripcion, severidad)
        VALUES ('ERROR_SP_VALIDARSTAGING',
                CONCAT('Error ', ERROR_NUMBER(), ': ', ERROR_MESSAGE()),
                'ERROR');

        THROW;
    END CATCH
END;
GO

/* ============================================================================
   PROCEDIMIENTO ALMACENADO 2: sp_CargarCasoVigilancia
   Propósito: tomar las filas VALIDO de staging y cargarlas al modelo 3FN,
   resolviendo (upsert) las dimensiones Ubicacion/Localidad y luego
   insertando en el hecho CasoVigilancia. Transacción con SAVEPOINT por
   dimensión: si falla la carga de Localidad, se revierte solo hasta ese
   punto y Ubicacion (ya insertada) permanece, evitando reprocesar todo.
   Alternativa descartada: un único INSERT...SELECT masivo sin upsert de
   dimensiones (asumiendo que ya existen). Se descartó porque (a) el
   staging puede traer ubigeos o diagnósticos no vistos previamente y
   fallaría por violación de FK, y (b) no deja rastro de qué combinaciones
   nuevas de dimensión se dieron de alta, dificultando la auditoría.
============================================================================ */
IF OBJECT_ID('dbo.sp_CargarCasoVigilancia', 'P') IS NOT NULL
    DROP PROCEDURE dbo.sp_CargarCasoVigilancia;
GO
CREATE PROCEDURE dbo.sp_CargarCasoVigilancia
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @filas_cargadas INT = 0;

    BEGIN TRY
        BEGIN TRANSACTION TrxCarga;

        -- 1) Upsert de Ubicacion
        SAVE TRANSACTION SP_Ubicacion;
        INSERT INTO dbo.Ubicacion (ubigeo, departamento, provincia, distrito, diresa)
        SELECT DISTINCT s.ubigeo, s.departamento, s.provincia, s.distrito, s.diresa
        FROM dbo.Staging_CasoVigilancia s
        WHERE s.estado_validacion = 'VALIDO'
          AND NOT EXISTS (SELECT 1 FROM dbo.Ubicacion u WHERE u.ubigeo = s.ubigeo);

        -- 2) Upsert de Localidad
        SAVE TRANSACTION SP_Localidad;
        INSERT INTO dbo.Localidad (ubigeo, localidad_nombre, localcod, tipo_localcod)
        SELECT DISTINCT s.ubigeo,
               ISNULL(s.localidad, 'NO ESPECIFICADO'),
               s.localcod,
               CASE WHEN s.localcod IS NULL THEN 'NO_ESPECIFICADO'
                    WHEN s.localcod NOT LIKE '%[^0-9]%' THEN 'NUMERICO'
                    ELSE 'ALFANUMERICO' END
        FROM dbo.Staging_CasoVigilancia s
        WHERE s.estado_validacion = 'VALIDO'
          AND NOT EXISTS (
                SELECT 1 FROM dbo.Localidad l
                WHERE l.ubigeo = s.ubigeo
                  AND l.localidad_nombre = ISNULL(s.localidad, 'NO ESPECIFICADO')
                  AND ISNULL(l.localcod,'') = ISNULL(s.localcod,'')
          );

        -- 3) Insercion del hecho CasoVigilancia (pasa por el trigger de integridad)
        SAVE TRANSACTION SP_Hecho;
        INSERT INTO dbo.CasoVigilancia
            (id_origen, ubigeo, id_localidad, diagnostic, ano, semana, edad, tipo_edad, sexo, flag_posible_duplicado)
        SELECT
            s.id_origen,
            s.ubigeo,
            l.id_localidad,
            s.diagnostic,
            TRY_CAST(s.ano AS SMALLINT),
            TRY_CAST(s.semana AS TINYINT),
            TRY_CAST(s.edad AS SMALLINT),
            s.tipo_edad,
            s.sexo,
            0
        FROM dbo.Staging_CasoVigilancia s
        JOIN dbo.Localidad l
          ON l.ubigeo = s.ubigeo
         AND l.localidad_nombre = ISNULL(s.localidad, 'NO ESPECIFICADO')
         AND ISNULL(l.localcod,'') = ISNULL(s.localcod,'')
        WHERE s.estado_validacion = 'VALIDO' AND s.procesado = 0;

        SET @filas_cargadas = @@ROWCOUNT;

        UPDATE dbo.Staging_CasoVigilancia
        SET procesado = 1
        WHERE estado_validacion = 'VALIDO' AND procesado = 0;

        COMMIT TRANSACTION TrxCarga;

        SELECT @filas_cargadas AS filas_cargadas_a_CasoVigilancia;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
            ROLLBACK TRANSACTION TrxCarga;

        INSERT INTO dbo.Log_ExcepcionesETL (regla, descripcion, severidad)
        VALUES ('ERROR_SP_CARGARCASOVIGILANCIA',
                CONCAT('Error ', ERROR_NUMBER(), ' en línea ', ERROR_LINE(), ': ', ERROR_MESSAGE()),
                'ERROR');

        THROW;
    END CATCH
END;
GO
