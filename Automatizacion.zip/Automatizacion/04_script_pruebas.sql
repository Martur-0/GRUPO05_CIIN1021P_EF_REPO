/* ============================================================================
   SCRIPT DE PRUEBAS - Paso 2
   Carga un lote de ejemplo a staging (incluyendo casos válidos y casos con
   errores intencionales) y ejecuta la cadena completa: validación -> carga
   -> triggers -> función, dejando registros de prueba en las tablas de log.
============================================================================ */
USE DIRESA_LaLibertad_Dengue;
GO

-- Limpieza de un run de prueba anterior (opcional, solo entorno de pruebas)
-- DELETE FROM dbo.Staging_CasoVigilancia;

INSERT INTO dbo.Staging_CasoVigilancia
    (id_origen, departamento, provincia, distrito, localidad, enfermedad, ano, semana,
     diagnostic, diresa, ubigeo, localcod, edad, tipo_edad, sexo)
VALUES
-- Caso válido 1
('T001','LA LIBERTAD','TRUJILLO','TRUJILLO','EL PORVENIR','DENGUE SIN SIGNOS DE ALARMA','2024','12','A97.0','13','130101','010203','34','A','F'),
-- Caso válido 2 (localidad no especificada, para probar el default)
('T002','LA LIBERTAD','TRUJILLO','LA ESPERANZA',NULL,'DENGUE CON SIGNOS DE ALARMA','2024','12','A97.1','13','130104',NULL,'8','A','M'),
-- Caso con sexo fuera de dominio -> debe ser rechazado por sp_ValidarStaging
('T003','LA LIBERTAD','TRUJILLO','TRUJILLO','CENTRO','DENGUE SIN SIGNOS DE ALARMA','2024','12','A97.0','13','130101','010204','40','A','X'),
-- Caso con semana fuera de rango -> debe ser rechazado
('T004','LA LIBERTAD','ASCOPE','ASCOPE','ASCOPE','DENGUE GRAVE','2024','60','A97.2','13','130201','020101','29','A','M'),
-- Caso con edad imposible para tipo_edad='A' -> pasa la validación de staging
-- (dominio correcto) pero debe ser rechazado por el trigger de integridad
('T005','LA LIBERTAD','TRUJILLO','TRUJILLO','BUENOS AIRES','DENGUE SIN SIGNOS DE ALARMA','2024','12','A97.0','13','130101','010205','150','A','F');
GO

PRINT '--- Ejecutando sp_ValidarStaging ---';
EXEC dbo.sp_ValidarStaging;
GO

PRINT '--- Estado de staging tras validacion ---';
SELECT id_staging, id_origen, estado_validacion FROM dbo.Staging_CasoVigilancia ORDER BY id_staging;
GO

PRINT '--- Ejecutando sp_CargarCasoVigilancia (T005 debe fallar por el trigger de integridad) ---';
BEGIN TRY
    EXEC dbo.sp_CargarCasoVigilancia;
END TRY
BEGIN CATCH
    PRINT 'Excepcion capturada en la prueba (esperada por T005): ' + ERROR_MESSAGE();
END CATCH
GO

-- Reintento sin el registro problemático T005 para demostrar la carga exitosa del resto
DELETE FROM dbo.Staging_CasoVigilancia WHERE id_origen = 'T005';
EXEC dbo.sp_ValidarStaging;
EXEC dbo.sp_CargarCasoVigilancia;
GO

PRINT '--- CasoVigilancia cargado ---';
SELECT c.id_caso, c.ubigeo, u.departamento, u.distrito, e.enfermedad_nombre, c.edad, c.tipo_edad,
       dbo.fn_ClasificarGrupoEtario(c.edad, c.tipo_edad) AS grupo_etario
FROM dbo.CasoVigilancia c
JOIN dbo.Ubicacion u ON u.ubigeo = c.ubigeo
JOIN dbo.Enfermedad e ON e.diagnostic = c.diagnostic;
GO

PRINT '--- Log_Auditoria (registros de prueba generados por el trigger de auditoria) ---';
SELECT id_log, tabla_afectada, operacion, id_registro, usuario_bd, fecha_hora
FROM dbo.Log_Auditoria ORDER BY id_log;
GO

-- Prueba de UPDATE para verificar que el trigger de auditoria tambien registra cambios
UPDATE dbo.CasoVigilancia SET edad = 35 WHERE id_origen = 'T001';
SELECT id_log, tabla_afectada, operacion, id_registro, valor_anterior, valor_nuevo
FROM dbo.Log_Auditoria WHERE operacion = 'UPDATE';
GO

PRINT '--- Log_ExcepcionesETL (evidencia de rechazos controlados) ---';
SELECT id_excepcion, id_staging, regla, descripcion, severidad, fecha_hora
FROM dbo.Log_ExcepcionesETL ORDER BY id_excepcion;
GO
