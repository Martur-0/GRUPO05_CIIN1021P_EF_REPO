/* ============================================================================
   PUENTE: dbo.dataset_limpio_etapa1 (tabla creada al importar el CSV limpio)
            -> dbo.Staging_CasoVigilancia (área de aterrizaje esperada por
               sp_ValidarStaging / sp_CargarCasoVigilancia)

   Ajusta los nombres de columna del SELECT si el asistente de importación
   de SSMS les puso otros nombres/tipos distintos al encabezado del CSV.
   Ejecuta primero: SELECT TOP 5 * FROM dbo.dataset_limpio_etapa1; para
   confirmar los nombres reales antes de correr este script.
============================================================================ */
USE DIRESA_LaLibertad_Dengue;
GO

INSERT INTO dbo.Staging_CasoVigilancia
    (id_origen, departamento, provincia, distrito, localidad, enfermedad, ano, semana,
     diagnostic, diresa, ubigeo, localcod, edad, tipo_edad, sexo)
SELECT
    CAST(id_origen AS VARCHAR(20)),
    departamento,
    provincia,
    distrito,
    NULLIF(localidad, 'NO ESPECIFICADO'),   -- se vuelve a dejar NULL; el proceso de carga ya sabe default-earlo
    enfermedad,
    CAST(ano AS VARCHAR(10)),
    CAST(semana AS VARCHAR(10)),
    diagnostic,
    diresa,
    ubigeo,
    NULLIF(localcod, 'NE'),
    CAST(edad AS VARCHAR(20)),
    tipo_edad,
    sexo
FROM dbo.dataset_limpio_etapa1;
GO

-- Verificacion rapida de volumen cargado
SELECT COUNT(*) AS filas_en_staging FROM dbo.Staging_CasoVigilancia;
GO
