/* ============================================================================
   06_cargar_produccion.sql
   Procesa en el modelo 3FN TODAS las filas de produccion que ya estan en
   Staging_CasoVigilancia (cargadas ahi por 05_puente_dataset_limpio_a_staging.sql).
   Ejecutar DESPUES de haber probado la cadena completa con datos de prueba
   (04_script_pruebas.sql) para no mezclar evidencia de prueba con la carga real.
============================================================================ */
USE DIRESA_LaLibertad_Dengue;
GO

PRINT '--- Filas pendientes en staging antes de procesar ---';
SELECT estado_validacion, COUNT(*) AS filas
FROM dbo.Staging_CasoVigilancia
GROUP BY estado_validacion;
GO

PRINT '--- Ejecutando sp_ValidarStaging sobre el lote de produccion ---';
EXEC dbo.sp_ValidarStaging;
GO

PRINT '--- Ejecutando sp_CargarCasoVigilancia sobre el lote de produccion ---';
EXEC dbo.sp_CargarCasoVigilancia;
GO

/* ----------------------------------------------------------------------
   Verificacion de resultados
---------------------------------------------------------------------- */
PRINT '--- Resumen final ---';
SELECT
    (SELECT COUNT(*) FROM dbo.Staging_CasoVigilancia)                          AS total_staging,
    (SELECT COUNT(*) FROM dbo.Staging_CasoVigilancia WHERE estado_validacion='RECHAZADO') AS rechazados,
    (SELECT COUNT(*) FROM dbo.Staging_CasoVigilancia WHERE procesado=1)        AS procesados,
    (SELECT COUNT(*) FROM dbo.CasoVigilancia)                                  AS total_casovigilancia,
    (SELECT COUNT(*) FROM dbo.Ubicacion)                                       AS total_ubicaciones,
    (SELECT COUNT(*) FROM dbo.Localidad)                                       AS total_localidades,
    (SELECT COUNT(DISTINCT id_registro) FROM dbo.Log_Auditoria WHERE operacion='INSERT') AS insercionesAuditadas;
GO

-- Si "rechazados" > 0, revisar el detalle antes de continuar:
SELECT TOP 50 * FROM dbo.Log_ExcepcionesETL WHERE regla = 'VALIDACION_DOMINIO' ORDER BY id_excepcion DESC;
GO

-- Si sp_CargarCasoVigilancia fallo por algun lote con edad/tipo_edad
-- incoherente que se haya colado, revisar aqui y volver a ejecutar el
-- procedimiento tras corregir/excluir esas filas de staging:
SELECT TOP 50 * FROM dbo.Log_ExcepcionesETL WHERE regla = 'EDAD_FUERA_DE_RANGO' ORDER BY id_excepcion DESC;
GO
