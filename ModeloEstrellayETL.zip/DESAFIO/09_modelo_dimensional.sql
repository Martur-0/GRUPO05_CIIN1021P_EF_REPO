/* ============================================================================
   PASO 5: MODELO DIMENSIONAL (ESTRELLA) - METODOLOGÍA KIMBALL
   Data Warehouse: DIRESA_LaLibertad_DWH
============================================================================ */

IF DB_ID('DIRESA_LaLibertad_DWH') IS NULL
BEGIN
    CREATE DATABASE DIRESA_LaLibertad_DWH;
END
GO

USE DIRESA_LaLibertad_DWH;
GO

-- 1. DIMENSIÓN UBICACIÓN
CREATE TABLE dbo.DimUbicacion (
    UbicacionKey    INT IDENTITY(1,1) PRIMARY KEY,
    Ubigeo          CHAR(6)       NOT NULL,
    Departamento    VARCHAR(60)   NOT NULL,
    Provincia       VARCHAR(60)   NOT NULL,
    Distrito        VARCHAR(60)   NOT NULL,
    Diresa          VARCHAR(10)   NULL
);
GO

-- 2. DIMENSIÓN DEMOGRAFÍA (Paciente)
CREATE TABLE dbo.DimDemografia (
    DemografiaKey   INT IDENTITY(1,1) PRIMARY KEY,
    Sexo            CHAR(1)       NOT NULL, -- 'M' o 'F'
    GrupoEtario     VARCHAR(20)   NOT NULL  -- Ej: 'NINO', 'ADULTO_MAYOR'
);
GO

-- 3. DIMENSIÓN TIEMPO (Periodo Epidemiológico)
CREATE TABLE dbo.DimTiempo (
    TiempoKey       INT IDENTITY(1,1) PRIMARY KEY,
    Anio            SMALLINT      NOT NULL,
    Semana          TINYINT       NOT NULL
);
GO

-- 4. DIMENSIÓN DIAGNÓSTICO
CREATE TABLE dbo.DimDiagnostico (
    DiagnosticoKey  INT IDENTITY(1,1) PRIMARY KEY,
    CodigoCIE10     VARCHAR(10)   NOT NULL, -- Ej: 'A97.0'
    Enfermedad      VARCHAR(100)  NOT NULL
);
GO

-- 5. TABLA DE HECHOS
CREATE TABLE dbo.FactCasoDengue (
    CasoKey         BIGINT IDENTITY(1,1) PRIMARY KEY,
    UbicacionKey    INT NOT NULL,
    DemografiaKey   INT NOT NULL,
    TiempoKey       INT NOT NULL,
    DiagnosticoKey  INT NOT NULL,
    
    -- Métricas / Hechos
    EdadReal        SMALLINT NULL,      -- Se guarda el número para cálculos de promedios si se requiere
    CantidadCasos   INT NOT NULL DEFAULT 1, -- Facilita el COUNT/SUM en PowerBI/Metabase
    
    CONSTRAINT FK_Fact_Ubicacion FOREIGN KEY (UbicacionKey) REFERENCES dbo.DimUbicacion(UbicacionKey),
    CONSTRAINT FK_Fact_Demografia FOREIGN KEY (DemografiaKey) REFERENCES dbo.DimDemografia(DemografiaKey),
    CONSTRAINT FK_Fact_Tiempo FOREIGN KEY (TiempoKey) REFERENCES dbo.DimTiempo(TiempoKey),
    CONSTRAINT FK_Fact_Diagnostico FOREIGN KEY (DiagnosticoKey) REFERENCES dbo.DimDiagnostico(DiagnosticoKey)
);
GO