/* ============================================================================
   PASO 3 - Roles de base de datos con privilegios diferenciados

   Fundamento legal/normativo:
     - Ley N.° 29733, Art. 9 (Principio de Seguridad): medidas técnicas,
       organizativas y legales para garantizar la seguridad de los datos.
     - Ley N.° 29733, Art. 3: los datos de salud son "datos sensibles" y
       reciben protección especial.
     - ISO/IEC 27001, Anexo A.9 (Control de acceso): principio de mínimo
       privilegio y segregación de funciones (A.9.2, A.9.4).

   Diseño de segregación (3 roles con privilegios NO solapados en lo
   sensible):
     1) rol_administrador_bd  -> gestiona el esquema y los datos operativos,
        pero tiene EXPLÍCITAMENTE DENEGADA la escritura sobre las tablas de
        auditoría: ni siquiera el administrador puede alterar el rastro de
        lo que él mismo hizo (separación de funciones, evita que una sola
        cuenta pueda modificar datos Y borrar evidencia de haberlo hecho).
     2) rol_analista_datos    -> solo lectura sobre el modelo 3FN para
        reportes/KPIs; SIN acceso a staging (datos crudos/no depurados) ni
        a las tablas de auditoría (minimización de datos, no necesita ver
        quién hizo qué para hacer análisis epidemiológico).
     3) rol_auditor           -> solo lectura sobre las tablas de auditoría
        y la definición de los objetos de BD, para verificar que los
        controles existen y se usan; SIN acceso a los datos clínicos en sí
        (CasoVigilancia/Staging), reduciendo la exposición de datos
        sensibles de salud a quien solo necesita fiscalizar el control, no
        los pacientes.
============================================================================ */
USE DIRESA_LaLibertad_Dengue;
GO

IF DATABASE_PRINCIPAL_ID('rol_administrador_bd') IS NULL CREATE ROLE rol_administrador_bd;
IF DATABASE_PRINCIPAL_ID('rol_analista_datos')   IS NULL CREATE ROLE rol_analista_datos;
IF DATABASE_PRINCIPAL_ID('rol_auditor')          IS NULL CREATE ROLE rol_auditor;
GO

/* ----------------------------------------------------------------------
   1) ROL ADMINISTRADOR DE BASE DE DATOS
---------------------------------------------------------------------- */
GRANT SELECT, INSERT, UPDATE, DELETE ON SCHEMA::dbo TO rol_administrador_bd;
GRANT ALTER ON SCHEMA::dbo TO rol_administrador_bd;
GRANT CREATE TABLE      TO rol_administrador_bd;
GRANT CREATE PROCEDURE  TO rol_administrador_bd;
GRANT CREATE FUNCTION   TO rol_administrador_bd;
GRANT CREATE VIEW       TO rol_administrador_bd;
GRANT BACKUP DATABASE   TO rol_administrador_bd;
GRANT BACKUP LOG        TO rol_administrador_bd;

-- Segregación de funciones: el administrador NO puede alterar ni borrar
-- el rastro de auditoría, aunque sí puede leerlo para operar.
DENY INSERT, UPDATE, DELETE ON dbo.Log_Auditoria      TO rol_administrador_bd;
DENY INSERT, UPDATE, DELETE ON dbo.Log_ExcepcionesETL TO rol_administrador_bd;
GO

/* ----------------------------------------------------------------------
   2) ROL ANALISTA DE DATOS (consumo para KPIs / Bloque 3 BI)
---------------------------------------------------------------------- */
GRANT SELECT ON dbo.CasoVigilancia TO rol_analista_datos;
GRANT SELECT ON dbo.Ubicacion      TO rol_analista_datos;
GRANT SELECT ON dbo.Localidad      TO rol_analista_datos;
GRANT SELECT ON dbo.Enfermedad     TO rol_analista_datos;
GRANT EXECUTE ON dbo.fn_ClasificarGrupoEtario TO rol_analista_datos;

-- Minimización de datos (Art. 9 Ley 29733): el analista no necesita ver
-- datos crudos sin validar ni el rastro de auditoría para hacer reportes.
DENY SELECT ON dbo.Staging_CasoVigilancia TO rol_analista_datos;
DENY SELECT ON dbo.Log_Auditoria          TO rol_analista_datos;
DENY SELECT ON dbo.Log_ExcepcionesETL     TO rol_analista_datos;
DENY INSERT, UPDATE, DELETE ON SCHEMA::dbo TO rol_analista_datos;
GO

/* ----------------------------------------------------------------------
   3) ROL AUDITOR (fiscalización de controles, Art. 9 Ley 29733 / ISO 27001 A.12.4)
---------------------------------------------------------------------- */
GRANT SELECT ON dbo.Log_Auditoria      TO rol_auditor;
GRANT SELECT ON dbo.Log_ExcepcionesETL TO rol_auditor;
GRANT VIEW DEFINITION ON SCHEMA::dbo   TO rol_auditor;  -- puede revisar el código de SP/triggers, no los datos

-- El auditor NO ve los datos clínicos/epidemiológicos en sí (minimización):
-- su función es verificar que el control (auditoría) existe y opera, no
-- consultar el historial de casos de dengue por paciente/localidad.
DENY SELECT ON dbo.CasoVigilancia         TO rol_auditor;
DENY SELECT ON dbo.Staging_CasoVigilancia TO rol_auditor;
DENY INSERT, UPDATE, DELETE ON SCHEMA::dbo TO rol_auditor;
GO

/* ----------------------------------------------------------------------
   4) Logins y usuarios de demostración
      (contraseñas de ejemplo: CAMBIAR antes de cualquier uso real)
---------------------------------------------------------------------- */
IF SUSER_ID('login_admin_diresa') IS NULL
    CREATE LOGIN login_admin_diresa WITH PASSWORD = 'CambiarInmediatamente_Adm#2026';
IF SUSER_ID('login_analista_diresa') IS NULL
    CREATE LOGIN login_analista_diresa WITH PASSWORD = 'CambiarInmediatamente_Ana#2026';
IF SUSER_ID('login_auditor_diresa') IS NULL
    CREATE LOGIN login_auditor_diresa WITH PASSWORD = 'CambiarInmediatamente_Aud#2026';
GO

IF DATABASE_PRINCIPAL_ID('usr_admin_diresa') IS NULL
    CREATE USER usr_admin_diresa FOR LOGIN login_admin_diresa;
IF DATABASE_PRINCIPAL_ID('usr_analista_diresa') IS NULL
    CREATE USER usr_analista_diresa FOR LOGIN login_analista_diresa;
IF DATABASE_PRINCIPAL_ID('usr_auditor_diresa') IS NULL
    CREATE USER usr_auditor_diresa FOR LOGIN login_auditor_diresa;
GO

ALTER ROLE rol_administrador_bd ADD MEMBER usr_admin_diresa;
ALTER ROLE rol_analista_datos   ADD MEMBER usr_analista_diresa;
ALTER ROLE rol_auditor          ADD MEMBER usr_auditor_diresa;
GO

/* ----------------------------------------------------------------------
   5) Verificación de permisos efectivos (evidencia para el informe)
---------------------------------------------------------------------- */
SELECT
    dp.name  AS rol,
    perm.class_desc,
    perm.permission_name,
    perm.state_desc,
    OBJECT_NAME(perm.major_id) AS objeto
FROM sys.database_permissions perm
JOIN sys.database_principals dp ON dp.principal_id = perm.grantee_principal_id
WHERE dp.name IN ('rol_administrador_bd','rol_analista_datos','rol_auditor')
ORDER BY dp.name, perm.state_desc, perm.permission_name;
GO
