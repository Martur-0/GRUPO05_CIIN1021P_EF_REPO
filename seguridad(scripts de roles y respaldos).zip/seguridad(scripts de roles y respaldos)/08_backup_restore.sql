/* ============================================================================
   PASO 3 - Política de respaldo y script de restauración probado

   Estrategia elegida: FULL semanal + DIFFERENTIAL diaria + LOG cada 1 hora
   (recovery model FULL), en vez de solo FULL+DIFFERENTIAL como sugiere el
   mínimo de la consigna.

   Justificación (2 criterios técnicos):
     1) RPO (punto de recuperación objetivo): con solo FULL+DIFFERENTIAL,
        el peor caso de pérdida de datos es de hasta 24 h (si el diferencial
        diario falla justo antes del siguiente). Para un sistema de
        vigilancia epidemiológica donde cada caso notificado puede activar
        una respuesta sanitaria, se justifica bajar el RPO a ~1 h agregando
        respaldo de log.
     2) RTO (tiempo objetivo de recuperación) y tamaño de la cadena de
        restauración: con backups DIFFERENTIAL diarios, restaurar solo
        requiere FULL + 1 DIFFERENTIAL + los LOG posteriores al diferencial,
        en vez de FULL + N backups incrementales encadenados, lo que acota
        el tiempo de restauración incluso creciendo el volumen de datos.
============================================================================ */
USE master;
GO

-- Recovery model FULL: obligatorio para poder hacer respaldo de log
ALTER DATABASE DIRESA_LaLibertad_Dengue SET RECOVERY FULL;
GO

/* ----------------------------------------------------------------------
   Backups (ajustar la ruta de disco a la del servidor real)
---------------------------------------------------------------------- */
-- FULL (ejecutar 1 vez por semana, p.ej. domingo 02:00, via SQL Agent Job)
BACKUP DATABASE DIRESA_LaLibertad_Dengue
TO DISK = 'C:\Backups\DIRESA_LaLibertad_Dengue_FULL.bak'
WITH INIT, COMPRESSION, CHECKSUM, STATS = 10,
     NAME = 'DIRESA_LaLibertad_Dengue-Full Backup';
GO

-- DIFFERENTIAL (ejecutar 1 vez al día, p.ej. 02:00, salvo el día del FULL)
BACKUP DATABASE DIRESA_LaLibertad_Dengue
TO DISK = 'C:\Backups\DIRESA_LaLibertad_Dengue_DIFF.bak'
WITH DIFFERENTIAL, COMPRESSION, CHECKSUM, STATS = 10,
     NAME = 'DIRESA_LaLibertad_Dengue-Differential Backup';
GO

-- LOG (ejecutar cada 1 hora en horario hábil, via SQL Agent Job)
BACKUP LOG DIRESA_LaLibertad_Dengue
TO DISK = 'C:\Backups\DIRESA_LaLibertad_Dengue_LOG.trn'
WITH COMPRESSION, CHECKSUM, STATS = 10,
     NAME = 'DIRESA_LaLibertad_Dengue-Log Backup';
GO

/* ----------------------------------------------------------------------
   RESTORE PROBADO: se restaura a una base de datos alterna
   (..._RESTORE_TEST) para verificar la cadena de backups SIN tocar el
   ambiente de producción. Antes de ejecutar, consultar los nombres
   lógicos reales de los archivos del backup:

       RESTORE FILELISTONLY FROM DISK = 'C:\Backups\DIRESA_LaLibertad_Dengue_FULL.bak';

   y ajustar los "MOVE" de abajo con los nombres lógicos que devuelva esa
   consulta (normalmente 'DIRESA_LaLibertad_Dengue' y
   'DIRESA_LaLibertad_Dengue_log').
---------------------------------------------------------------------- */
RESTORE DATABASE DIRESA_LaLibertad_Dengue_RESTORE_TEST
FROM DISK = 'C:\Backups\DIRESA_LaLibertad_Dengue_FULL.bak'
WITH MOVE 'DIRESA_LaLibertad_Dengue'     TO 'C:\SQLData\DIRESA_LaLibertad_Dengue_RESTORE_TEST.mdf',
     MOVE 'DIRESA_LaLibertad_Dengue_log' TO 'C:\SQLData\DIRESA_LaLibertad_Dengue_RESTORE_TEST_log.ldf',
     NORECOVERY, REPLACE, STATS = 10;
GO

RESTORE DATABASE DIRESA_LaLibertad_Dengue_RESTORE_TEST
FROM DISK = 'C:\Backups\DIRESA_LaLibertad_Dengue_DIFF.bak'
WITH NORECOVERY, STATS = 10;
GO

RESTORE LOG DIRESA_LaLibertad_Dengue_RESTORE_TEST
FROM DISK = 'C:\Backups\DIRESA_LaLibertad_Dengue_LOG.trn'
WITH RECOVERY, STATS = 10;
GO

/* ----------------------------------------------------------------------
   Verificación post-restauración (evidencia de que el restore fue exitoso
   y que los datos/objetos de auditoría llegaron íntegros)
---------------------------------------------------------------------- */
USE DIRESA_LaLibertad_Dengue_RESTORE_TEST;
GO
SELECT COUNT(*) AS casos_restaurados             FROM dbo.CasoVigilancia;
SELECT COUNT(*) AS registros_auditoria_restaurados FROM dbo.Log_Auditoria;
SELECT COUNT(*) AS ubicaciones_restauradas       FROM dbo.Ubicacion;
GO
-- Comparar estos conteos contra los mismos SELECT ejecutados sobre
-- DIRESA_LaLibertad_Dengue (producción) al momento del backup: deben coincidir.

-- Limpieza del ambiente de prueba de restore (opcional, tras validar):
-- USE master; DROP DATABASE DIRESA_LaLibertad_Dengue_RESTORE_TEST;
